import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { players, rooms, votes } from "@/db/schema";
import {
  getLocation,
  LOCATIONS,
  type RoomState,
  type VoteStat,
} from "@/lib/game";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code: rawCode } = await ctx.params;
  const code = rawCode.toUpperCase();
  const token = new URL(req.url).searchParams.get("token");

  const [room] = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!room) {
    return NextResponse.json({ error: "Room not found" }, { status: 404 });
  }

  const roomPlayers = await db
    .select()
    .from(players)
    .where(eq(players.roomId, room.id))
    .orderBy(players.joinedAt);

  const you = token ? roomPlayers.find((p) => p.token === token) ?? null : null;
  const isPlaying = room.phase !== "lobby";
  const location = getLocation(room.locationId);
  const role =
    you && isPlaying && room.spyPlayerId ? (you.id === room.spyPlayerId ? "spy" : "citizen") : null;

  const voteRows = await db
    .select()
    .from(votes)
    .where(and(eq(votes.roomId, room.id), eq(votes.round, room.round)));

  let voteStats: VoteStat | null = null;
  if (room.phase === "voting") {
    const counts: Record<string, number> = {};
    let abstain = 0;
    for (const v of voteRows) {
      if (v.targetPlayerId) counts[v.targetPlayerId] = (counts[v.targetPlayerId] ?? 0) + 1;
      else abstain++;
    }
    voteStats = {
      counts,
      abstain,
      cast: voteRows.length,
      votedPlayerIds: roomPlayers
        .filter((p) => voteRows.some((v) => v.voterToken === p.token))
        .map((p) => p.id),
    };
  }

  let votesOut: RoomState["votes"] = null;
  if (room.phase === "spy-guess" || room.phase === "round-end") {
    votesOut = voteRows.map((v) => {
      const voter = roomPlayers.find((p) => p.token === v.voterToken);
      const target = v.targetPlayerId ? roomPlayers.find((p) => p.id === v.targetPlayerId) : null;
      return {
        voterName: voter?.name ?? "?",
        voterEmoji: voter?.emoji ?? "❓",
        targetName: target?.name ?? null,
        targetEmoji: target?.emoji ?? null,
      };
    });
  }

  const state: RoomState = {
    room: {
      code: room.code,
      phase: room.phase as RoomState["room"]["phase"],
      round: room.round,
      deadlineMs: room.phaseDeadlineMs ?? null,
      spyId: room.phase === "round-end" ? room.spyPlayerId : null,
    },
    players: roomPlayers.map((p) => ({ id: p.id, name: p.name, emoji: p.emoji, isHost: p.isHost })),
    voteStats,
    votes: votesOut,
    result: room.result ?? null,
    you: you
      ? {
          playerId: you.id,
          name: you.name,
          emoji: you.emoji,
          isHost: you.isHost,
          role,
          location: role === "citizen" && location ? { ...location } : null,
          possibleLocations: role === "spy" ? LOCATIONS.map((l) => ({ id: l.id, name: l.name, emoji: l.emoji })) : null,
        }
      : null,
  };

  return NextResponse.json(state);
}
