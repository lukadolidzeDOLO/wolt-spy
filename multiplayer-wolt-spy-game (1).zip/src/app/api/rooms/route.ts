import { NextResponse } from "next/server";
import { db } from "@/db";
import { players, rooms } from "@/db/schema";
import { EMOJIS, genRoomCode, sanitizeName } from "@/lib/game";

export async function POST(req: Request) {
  let body: { name?: unknown; emoji?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const name = sanitizeName(body.name);
  if (!name) {
    return NextResponse.json({ error: "Please enter a name" }, { status: 400 });
  }
  const emoji = typeof body.emoji === "string" && EMOJIS.includes(body.emoji) ? body.emoji : "🕵️";
  const token = crypto.randomUUID();

  for (let attempt = 0; attempt < 12; attempt++) {
    const code = genRoomCode();
    try {
      const [room] = await db.insert(rooms).values({ code }).returning();
      const [player] = await db
        .insert(players)
        .values({ roomId: room.id, token, name, emoji, isHost: true })
        .returning();
      return NextResponse.json({ ok: true, code, token, playerId: player.id });
    } catch (e) {
      const err = e as { code?: string };
      if (err?.code === "23505") continue; // code collision — retry
      throw e;
    }
  }
  return NextResponse.json({ error: "Could not generate a room code, try again" }, { status: 500 });
}
